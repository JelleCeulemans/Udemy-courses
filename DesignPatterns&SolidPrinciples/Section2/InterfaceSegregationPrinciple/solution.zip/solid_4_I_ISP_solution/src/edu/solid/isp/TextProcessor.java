package edu.solid.isp;

/**
 * Simple version interface
 */
public interface TextProcessor {

	void add(String word);

	String text();

}